#ifndef OVERFLOW_CHECKER_H
#define OVERFLOW_CHECKER_H
#define TRUE 1
#define FALSE 0

int chk_overflow(unsigned long uptime, unsigned long previous_time);
#endif
