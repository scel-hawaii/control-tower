HIH613x
=======
An Arduino library to read Honeywell HIH613x humidity and temperature sensors.

History
=======
0.1
---

* Initial version

About
=====
Author: Antoine Bertin

License: MIT
